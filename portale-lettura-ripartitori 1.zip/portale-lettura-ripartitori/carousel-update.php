<?php
if (!defined('ABSPATH')) exit;
function plr_carousel_form($ids) {
    $notice = get_option('plr_carousel_notice');
    if ($notice) echo '<div class="notice notice-info"><p>'.esc_html($notice).'</p></div>';
    if (empty($ids['home']) || !get_post($ids['home'])) return;
    echo '<h2>Caroselli Home</h2><p>Sostituisce le due immagini originali con due caroselli da cinque foto. Conserva testi, stato della pagina e intestazione. Salva una copia del contenuto precedente nei metadati della Home.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
    wp_nonce_field('plr_carousels');
    echo '<input type="hidden" name="action" value="plr_carousels">';
    submit_button('Aggiungi i due caroselli alla Home','secondary');
    echo '</form><p>In Gutenberg apri il gruppo “Carosello dispositivi” o “Carosello ambienti” per sostituire o riordinare le immagini. Il movimento si vede in Anteprima.</p>';
}
// Replace only uniquely identified original image blocks, never an entire section.
function plr_carousel_walk(&$blocks, $originals, $replacement, &$counts) {
    foreach ($blocks as &$block) {
        if (($block['blockName'] ?? '') === 'core/image') {
            foreach ($originals as $key => $url) {
                $html = $block['innerHTML'] ?? '';
                if (preg_match('/\bsrc=["\x27]([^"\x27]+)["\x27]/', $html, $m) && html_entity_decode($m[1], ENT_QUOTES, 'UTF-8') === html_entity_decode($url, ENT_QUOTES, 'UTF-8')) {
                    $counts[$key]++;
                    if (isset($replacement[$key])) $block = $replacement[$key];
                    break;
                }
            }
        } elseif (!empty($block['innerBlocks'])) plr_carousel_walk($block['innerBlocks'], $originals, $replacement, $counts);
    }
}
function plr_carousels() {
    if (!current_user_can('manage_options') || !current_user_can('upload_files')) wp_die('Permessi insufficienti.');
    check_admin_referer('plr_carousels');
    if (!add_option('plr_import_lock',time(),'','no')) {
        if(time()-(int)get_option('plr_import_lock')<300) wp_die('Operazione già in corso. Riprova tra poco.');
        delete_option('plr_import_lock');
        if(!add_option('plr_import_lock',time(),'','no')) wp_die('Riprova tra poco.');
    }
    try {
        $ids = (array)get_option('plr_page_ids', array());
        $id = isset($ids['home']) ? (int)$ids['home'] : 0;
        $post = get_post($id);
        if (!$id || !$post || $post->post_type !== 'page' || !get_post_meta($id,'_plr_owned',true) || !current_user_can('edit_post',$id)) throw new Exception('Home del progetto non trovata o non modificabile.');
        $before = $post->post_content;
        if (strpos($before,'plr-carousel-dispositivo') !== false && strpos($before,'plr-carousel-ambiente') !== false) {
            update_option('plr_carousel_notice','I due caroselli sono già presenti. Nessuna modifica eseguita.',false);
        } else {
            $media = (array)get_option('plr_media_ids',array());
            $originals = array();
            foreach(array('ripartitore'=>'dispositivo','studio'=>'ambiente') as $old=>$key) {
                $url = !empty($media[$old]) ? wp_get_attachment_url($media[$old]) : false;
                if (!$url) throw new Exception('Immagine originale non trovata. Nessuna modifica alla Home.');
                $originals[$key] = $url;
            }
            $blocks = parse_blocks($before); $counts = array('dispositivo'=>0,'ambiente'=>0);
            plr_carousel_walk($blocks,$originals,array(),$counts);
            if ($counts['dispositivo'] !== 1 || $counts['ambiente'] !== 1) throw new Exception('Le immagini della Home sono state modificate o duplicate. Aggiornamento automatico interrotto per conservare il tuo lavoro.');
            $keys = array(); foreach(array('dispositivo','ambiente') as $key) for($n=1;$n<=5;$n++) $keys[]=$key.'-'.$n;
            $urls = plr_media($keys); $replacement = array();
            foreach(array('dispositivo','ambiente') as $key) {
                $file = file_get_contents(PLR_DIR.'pages/carousel-'.$key.'.html');
                if ($file === false) throw new Exception('Modello del carosello mancante.');
                $parsed = parse_blocks(strtr($file,$urls)); $replacement[$key] = $parsed[0];
            }
            $counts = array('dispositivo'=>0,'ambiente'=>0);
            plr_carousel_walk($blocks,$originals,$replacement,$counts);
            if (get_post_field('post_content',$id) !== $before) throw new Exception('La Home è stata modificata nel frattempo. Riprova.');
            add_post_meta($id,'_plr_carousel_backup',wp_slash($before),true);
            $result = wp_update_post(wp_slash(array('ID'=>$id,'post_content'=>serialize_blocks($blocks))),true);
            if (is_wp_error($result)) throw new Exception($result->get_error_message());
            update_option('plr_carousel_notice','Home aggiornata: due caroselli da cinque immagini. Testi e intestazione conservati. Apri Anteprima per verificarli.',false);
        }
    } catch(Exception $e) { update_option('plr_carousel_notice',$e->getMessage(),false); }
    delete_option('plr_import_lock');
    wp_safe_redirect(admin_url('tools.php?page=plr-pagine')); exit;
}
add_action('admin_post_plr_carousels','plr_carousels');
