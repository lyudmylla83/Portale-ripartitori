(function () {
  'use strict';
  function init() {
    document.querySelectorAll('.plr-header .plr-header-inner').forEach(function (header, index) {
      if (header.classList.contains('plr-nav-ready')) return;
      var menu = header.querySelector('.plr-menu');
      var brand = header.querySelector('.plr-brand');
      var cta = header.querySelector('.wp-block-buttons');
      if (!menu || !brand || !cta) return;
      var panel = document.createElement('div');
      panel.className = 'plr-nav-panel';
      panel.id = 'plr-nav-panel-' + index;
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'plr-nav-toggle';
      button.setAttribute('aria-controls', panel.id);
      button.innerHTML = '<span class="plr-nav-icon" aria-hidden="true"><span></span><span></span><span></span></span>';
      header.appendChild(button);
      header.appendChild(panel);
      panel.appendChild(menu);
      panel.appendChild(cta);
      var mobile = window.matchMedia('(max-width: 781px)');
      var open = false;
      function render() {
        button.hidden = !mobile.matches;
        panel.hidden = mobile.matches && !open;
        button.setAttribute('aria-expanded', String(mobile.matches && open));
        button.setAttribute('aria-label', open && mobile.matches ? 'Chiudi menu' : 'Apri menu');
        header.classList.toggle('plr-nav-open', mobile.matches && open);
      }
      button.addEventListener('click', function () { open = !open; render(); });
      header.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && mobile.matches && open) {
          event.preventDefault(); open = false; render(); button.focus();
        }
      });
      panel.addEventListener('click', function (event) {
        if (event.target.closest('a') && mobile.matches) { open = false; render(); button.focus(); }
      });
      document.addEventListener('click', function (event) {
        if (mobile.matches && open && !header.contains(event.target)) { open = false; render(); }
      });
      function resize() {
        var focusWasInside = panel.contains(document.activeElement);
        open = false; render();
        if (mobile.matches && focusWasInside) button.focus();
        else if (!mobile.matches && document.activeElement === button) menu.querySelector('a').focus();
      }
      if (mobile.addEventListener) mobile.addEventListener('change', resize);
      else mobile.addListener(resize);
      header.classList.add('plr-nav-ready');
      render();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
