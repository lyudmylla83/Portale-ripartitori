<?php
if(!defined('ABSPATH'))exit;
function plr_webp_controls(){
    echo '<h2>Immagini WebP e collegamenti partner</h2><p>Aggiorna le immagini importate dal progetto in formato WebP e collega i loghi del footer ai siti dei partner. Mantiene testi, ordine dei caroselli e stato delle pagine.</p>';
    $notice=get_option('plr_webp_notice');if($notice)echo '<p>'.esc_html($notice).'</p>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('plr_webp');echo '<input type="hidden" name="action" value="plr_webp">';submit_button('Aggiorna immagini WebP e link del footer','secondary');echo '</form>';
}
function plr_webp_import(){
    require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
    $ids=(array)get_option('plr_webp_ids_140',array());
    foreach(array('pc','mobile','tablet','montaggio','studio','ripartitore','dispositivo-1','dispositivo-2','dispositivo-3','dispositivo-4','dispositivo-5','ambiente-1','ambiente-2','ambiente-3','ambiente-4','ambiente-5','logo-lr','logo-agenzia','logo-kds') as $key){
        if(!empty($ids[$key])&&wp_get_attachment_url($ids[$key]))continue;
        $tmp=wp_tempnam($key.'.webp');if(!$tmp||!copy(PLR_DIR.'assets/'.$key.'.webp',$tmp))throw new Exception('Immagine non disponibile: '.$key);
        $id=media_handle_sideload(array('name'=>'lettura-ripartitori-140-'.$key.'.webp','tmp_name'=>$tmp),0,'Lettura Ripartitori — '.$key);
        if(is_wp_error($id)){if(file_exists($tmp))unlink($tmp);throw new Exception($id->get_error_message());}
        $ids[$key]=$id;update_option('plr_webp_ids_140',$ids,false);
    }
    return $ids;
}
function plr_webp_blocks($blocks,$map,$partner=false){
    foreach($blocks as &$b){
        $in_partner=$partner||in_array('plr-footer-logos',preg_split('/\s+/',trim($b['attrs']['className']??'')),true);
        if(($b['blockName']??'')==='core/image' && preg_match('/\bsrc="([^"]+)"/',$b['innerHTML'],$m)){
            $src=html_entity_decode($m[1],ENT_QUOTES,'UTF-8');$entry=$map[$src]??null;
            if($entry){
                $html=$b['innerHTML'];
                $html=preg_replace('/\bsrc="[^"]+"/','src="'.esc_url($entry['url']).'"',$html,1);
                $html=preg_replace('/\s(?:srcset|sizes)="[^"]*"/','',$html);
                // Retain dimensions and presentation, update attachment class when present.
                if(isset($b['attrs']['id'])){$b['attrs']['id']=$entry['id'];$html=preg_replace('/wp-image-\d+/','wp-image-'.$entry['id'],$html);}
                $target=$in_partner?($entry['key']==='logo-agenzia'?'https://agenziadellaria.it/':($entry['key']==='logo-kds'?'https://www.konsol.it/':null)):null;
                if($target){
                    $html=preg_replace('/<a\b[^>]*>(\s*<img\b[^>]*>\s*)<\/a>/','$1',$html);
                    $html=preg_replace('/(<img\b[^>]*>)/','<a href="'.$target.'">$1</a>',$html,1);
                    $b['attrs']['linkDestination']='custom';unset($b['attrs']['linkTarget'],$b['attrs']['rel']);
                }
                $b['innerHTML']=$html;$b['innerContent']=array($html);
            }
        }
        if(!empty($b['innerBlocks']))$b['innerBlocks']=plr_webp_blocks($b['innerBlocks'],$map,$in_partner);
    }
    return $blocks;
}
function plr_webp_action(){
    if(!current_user_can('manage_options')||!current_user_can('edit_pages')||!current_user_can('upload_files'))wp_die('Permessi insufficienti.');
    check_admin_referer('plr_webp');
    if(!add_option('plr_import_lock',time(),'','no'))wp_die('Operazione in corso. Riprova tra poco.');
    try{
        $pages=(array)get_option('plr_page_ids',array());if(!$pages)throw new Exception('Importa prima le quattro pagine.');
        $ids=plr_webp_import();$map=array();
        foreach(array((array)get_option('plr_media_ids',array()),(array)get_option('plr_photo_ids_130',array()),$ids) as $old){
            foreach($old as $key=>$id){if(!isset($ids[$key]))continue;$entry=array('key'=>$key,'id'=>$ids[$key],'url'=>wp_get_attachment_url($ids[$key]));$url=wp_get_attachment_url($id);if($url)$map[$url]=$entry;
                foreach(array('thumbnail','medium','medium_large','large','full') as $size){$img=wp_get_attachment_image_src($id,$size);if($img)$map[$img[0]]=$entry;}
            }
        }
        foreach(array('logo-agenzia'=>array('png','webp'),'logo-kds'=>array('jpg','webp')) as $key=>$exts)foreach($exts as $ext)$map[PLR_URL.'assets/'.$key.'.'.$ext]=array('key'=>$key,'id'=>$ids[$key],'url'=>wp_get_attachment_url($ids[$key]));
        $footer=plr_footer_post();if($footer)$pages['footer']=$footer->ID;
        $plans=array();foreach($pages as $key=>$id){
            if(!current_user_can('edit_post',$id))throw new Exception('Contenuto non modificabile.');
            if($key!=='footer'&&!get_post_meta($id,'_plr_owned',true))throw new Exception('Pagina non appartenente al progetto.');
            if(get_post_meta($id,'_plr_webp_140',true))continue;
            $before=get_post_field('post_content',$id);$after=serialize_blocks(plr_webp_blocks(parse_blocks($before),$map));$plans[]=array($id,$before,$after);
        }
        foreach($plans as $p)if(get_post_field('post_content',$p[0])!==$p[1])throw new Exception('Contenuto modificato nel frattempo. Riprova.');
        foreach($plans as $p){list($id,$before,$after)=$p;add_post_meta($id,'_plr_webp_backup_140',wp_slash($before),true);if($before!==$after){$result=wp_update_post(wp_slash(array('ID'=>$id,'post_content'=>$after)),true);if(is_wp_error($result))throw new Exception($result->get_error_message());}update_post_meta($id,'_plr_webp_140',1);}
        if(!get_option('plr_webp_logo_140')){add_option('plr_webp_brand_backup_140',array('custom_logo'=>get_theme_mod('custom_logo'),'plr_logo_130'=>get_option('plr_logo_130')),'','no');update_option('plr_logo_130',$ids['logo-lr'],false);set_theme_mod('custom_logo',$ids['logo-lr']);update_option('plr_webp_logo_140',1,false);}
        update_option('plr_webp_notice','Immagini WebP aggiornate. '.($footer?'Loghi del footer collegati ai siti dei partner.':'Attiva il footer condiviso per visualizzare i loghi con i collegamenti.'),false);
    }catch(Exception $e){update_option('plr_webp_notice',$e->getMessage(),false);}
    delete_option('plr_import_lock');wp_safe_redirect(admin_url('tools.php?page=plr-pagine'));exit;
}
add_action('admin_post_plr_webp','plr_webp_action');
