<?php
if (!defined('ABSPATH')) exit;
function plr_footer_post() {
    $id=(int)get_option('plr_footer_id');
    $post=$id?get_post($id):null;
    return $post && $post->post_type==='wp_block' && $post->post_status==='publish' ? $post : null;
}
function plr_footer_controls() {
    $post=plr_footer_post();
    echo '<h2>Footer condiviso</h2>';
    if ($post) {
        echo '<p>Il footer è attivo su tutte le pagine del progetto. <a href="'.esc_url(get_edit_post_link($post->ID)).'">Modifica footer condiviso</a>. Le modifiche si applicano a tutte le pagine.</p>';
    }
    if (!$post || !get_option('plr_footer_logos_applied')) {
        echo '<p>Crea o aggiorna un pattern sincronizzato con Contatti, email e attribuzione. Il footer compare automaticamente sulle pagine del progetto, senza modificare il loro contenuto.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('plr_footer_create');
        echo '<input type="hidden" name="action" value="plr_footer_create">';
        submit_button($post?'Aggiorna footer: telefono e loghi':'Attiva footer condiviso','secondary');
        echo '</form>';
    }
}
function plr_footer_create() {
    if (!current_user_can('manage_options') || !current_user_can('edit_pages')) wp_die('Permessi insufficienti.');
    check_admin_referer('plr_footer_create');

    if (!add_option('plr_footer_lock',time(),'','no')) {
        if(time()-(int)get_option('plr_footer_lock')<300) wp_die('Creazione footer già in corso. Riprova tra poco.');
        delete_option('plr_footer_lock');
        if(!add_option('plr_footer_lock',time(),'','no')) wp_die('Riprova tra poco.');
    }
    try {
        $post=plr_footer_post();
        if ($post) {
            $before=$post->post_content;
            $blocks=parse_blocks($before);$matches=0;
            plr_footer_upgrade_blocks($blocks,$matches);
            if($matches!==1) throw new Exception('Footer personalizzato: contenitore non riconosciuto. Nessuna modifica eseguita.');
            if(get_post_field('post_content',$post->ID)!==$before) throw new Exception('Footer modificato nel frattempo. Riprova.');
            add_post_meta($post->ID,'_plr_footer_before_logos',wp_slash($before),true);
            $id=wp_update_post(wp_slash(array('ID'=>$post->ID,'post_content'=>serialize_blocks($blocks))),true);
        } else {
            $content=plr_footer_fragment('footer');
            $id=wp_insert_post(wp_slash(array('post_type'=>'wp_block','post_status'=>'publish','post_title'=>'Portale — Footer condiviso','post_content'=>$content)),true);
        }
        if(is_wp_error($id)) throw new Exception($id->get_error_message());
        update_option('plr_footer_id',$id,false);
        update_option('plr_footer_logos_applied',1,false);
    } catch(Exception $e) {
        delete_option('plr_footer_lock');wp_die(esc_html($e->getMessage()));
    }
    delete_option('plr_footer_lock');
    wp_safe_redirect(admin_url('tools.php?page=plr-pagine'));exit;
}
add_action('admin_post_plr_footer_create','plr_footer_create');
function plr_render_footer() {
    $post=plr_footer_post();
    if($post) echo '<footer class="plr-footer" aria-label="Contatti">'.do_blocks($post->post_content).'</footer>';
}

function plr_footer_fragment($name) {
    $content=file_get_contents(PLR_DIR.'pages/'.$name.'.html');
    if($content===false) throw new Exception('Modello footer mancante.');
    return strtr($content,array('{{footer:agenzia}}'=>esc_url(PLR_URL.'assets/logo-agenzia.webp'),'{{footer:kds}}'=>esc_url(PLR_URL.'assets/logo-kds.webp')));
}
function plr_footer_has_class($block,$class) {
    if(in_array($class,preg_split('/\s+/',trim($block['attrs']['className'] ?? '')),true)) return true;
    foreach($block['innerBlocks'] ?? array() as $child) if(plr_footer_has_class($child,$class)) return true;
    return false;
}
function plr_footer_upgrade_blocks(&$blocks,&$matches) {
    foreach($blocks as &$block) {
        if(in_array('plr-footer-inner',preg_split('/\s+/',trim($block['attrs']['className'] ?? '')),true)) {
            $matches++;
            foreach(array('plr-footer-phone'=>'footer-phone','plr-footer-logos'=>'footer-logos') as $class=>$file) {
                if(plr_footer_has_class($block,$class)) continue;
                $new=parse_blocks(plr_footer_fragment($file));
                // Insert the phone before the credit, preserving existing text and blocks.
                $index=count($block['innerBlocks']);
                if($class==='plr-footer-phone') foreach($block['innerBlocks'] as $i=>$child) {
                    if(plr_footer_has_class($child,'plr-footer-credit')) {$index=$i;break;}
                }
                $slot=count($block['innerContent'])-1;$seen=0;
                foreach($block['innerContent'] as $i=>$part) if($part===null) {
                    if($seen===$index){$slot=$i;break;}$seen++;
                }
                array_splice($block['innerBlocks'],$index,0,array($new[0]));
                array_splice($block['innerContent'],$slot,0,array(null));
            }
        } else if(!empty($block['innerBlocks'])) plr_footer_upgrade_blocks($block['innerBlocks'],$matches);
    }
}
