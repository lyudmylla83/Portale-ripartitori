<?php if(!defined('ABSPATH')) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="plr-skip" href="#plr-main">Vai al contenuto</a>
<header class="plr-header"><nav aria-label="Navigazione principale"><?php $plr_header=get_post((int)get_option('plr_header_id'));if($plr_header && $plr_header->post_type==='wp_block') echo do_blocks($plr_header->post_content); ?></nav></header>
<main id="plr-main"><?php while(have_posts()):the_post();the_content();endwhile; ?></main>
<?php wp_footer(); ?>
</body></html>
