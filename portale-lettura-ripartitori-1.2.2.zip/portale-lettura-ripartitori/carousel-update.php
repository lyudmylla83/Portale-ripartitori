<?php
if (!defined('ABSPATH')) exit;
function plr_carousel_form($ids) {
    $notice = get_option('plr_carousel_notice');
    if ($notice) echo '<div class="notice notice-info"><p>'.esc_html($notice).'</p></div>';
    if (empty($ids['home']) || !get_post($ids['home'])) return;
    echo '<h2>Caroselli Home</h2><p>Sostituisce le due immagini originali con due caroselli da cinque foto. Conserva testi, stato della pagina e intestazione. Salva una copia del contenuto precedente nei metadati della Home.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
    wp_nonce_field('plr_carousels');
    echo '<input type="hidden" name="action" value="plr_carousels">';
    submit_button('Aggiungi i due caroselli alla Home','secondary');
    echo '</form><p>In Gutenberg apri il gruppo “Carosello dispositivi” o “Carosello ambienti” per sostituire o riordinare le immagini. Il movimento si vede in Anteprima.</p>';
}
// Locate the two named sections, independently from attachment URLs and sizes.
function plr_carousel_text($block) {
    $text = strip_tags($block['innerHTML'] ?? '');
    foreach ($block['innerBlocks'] ?? array() as $child) $text .= ' '.plr_carousel_text($child);
    return preg_replace('/\s+/u', ' ', html_entity_decode($text, ENT_QUOTES, 'UTF-8'));
}
function plr_carousel_targets($blocks, $mode = 'section', $path = array()) {
    $found = array('dispositivo'=>array(), 'ambiente'=>array());
    foreach ($blocks as $i=>$block) {
        $here = array_merge($path,array($i));
        $classes = preg_split('/\s+/',trim($block['attrs']['className'] ?? ''));
        $candidate = $mode === 'section' ? in_array('plr-section',$classes,true) : ($block['blockName'] ?? '') === 'core/columns';
        if ($candidate) {
            $text = plr_carousel_text($block);
            foreach(array('dispositivo'=>'Dal radiatore alla consultazione', 'ambiente'=>'RACCOLTA E ACCESSO') as $key=>$label) {
                if (stripos($text,$label)!==false) $found[$key][]=$here;
            }
        }
        $nested = plr_carousel_targets($block['innerBlocks'] ?? array(),$mode,$here);
        foreach($found as $key=>$unused) $found[$key]=array_merge($found[$key],$nested[$key]);
    }
    return $found;
}
function &plr_carousel_at(&$blocks,$path) {
    $i=array_shift($path);
    if (!$path) return $blocks[$i];
    return plr_carousel_at($blocks[$i]['innerBlocks'],$path);
}
function plr_carousel_images($blocks, $path=array()) {
    $found=array();
    foreach($blocks as $i=>$block) {
        $here=array_merge($path,array($i));
        if (($block['blockName'] ?? '')==='core/image') $found[]=$here;
        else $found=array_merge($found,plr_carousel_images($block['innerBlocks'] ?? array(),$here));
    }
    return $found;
}
function plr_carousel_existing($block,$key) {
    $classes=preg_split('/\s+/',trim($block['attrs']['className'] ?? ''));
    $n=in_array('plr-carousel-'.$key,$classes,true)?1:0;
    foreach($block['innerBlocks'] ?? array() as $child) $n+=plr_carousel_existing($child,$key);
    return $n;
}
function plr_carousel_plan(&$blocks) {
    $found=plr_carousel_targets($blocks); $fallback=plr_carousel_targets($blocks,'columns'); $plan=array();
    foreach($found as $key=>$sections) {
        if (!$sections) $sections=$fallback[$key];
        if(count($sections)!==1) throw new Exception('Sezione '.$key.' non identificata in modo univoco. Nessuna modifica alla Home.');
        $section=&plr_carousel_at($blocks,$sections[0]);
        $existing=plr_carousel_existing($section,$key);
        if ($existing===1) continue;
        if ($existing>1) throw new Exception('Caroselli duplicati nella sezione '.$key.'. Nessuna modifica alla Home.');
        $images=plr_carousel_images($section['innerBlocks'] ?? array());
        if(count($images)!==1) throw new Exception('La sezione '.$key.' contiene '.count($images).' immagini invece di una. Nessuna modifica alla Home.');
        $plan[$key]=array_merge($sections[0],$images[0]);
    }
    return $plan;
}
function plr_carousels() {
    if (!current_user_can('manage_options') || !current_user_can('upload_files')) wp_die('Permessi insufficienti.');
    check_admin_referer('plr_carousels');
    if (!add_option('plr_import_lock',time(),'','no')) {
        if(time()-(int)get_option('plr_import_lock')<300) wp_die('Operazione già in corso. Riprova tra poco.');
        delete_option('plr_import_lock');
        if(!add_option('plr_import_lock',time(),'','no')) wp_die('Riprova tra poco.');
    }
    try {
        $ids = (array)get_option('plr_page_ids', array());
        $id = isset($ids['home']) ? (int)$ids['home'] : 0;
        $post = get_post($id);
        if (!$id || !$post || $post->post_type !== 'page' || !get_post_meta($id,'_plr_owned',true) || !current_user_can('edit_post',$id)) throw new Exception('Home del progetto non trovata o non modificabile.');
        $before = $post->post_content;
        $blocks = parse_blocks($before);
        $plan = plr_carousel_plan($blocks);
        if (!$plan) {
            update_option('plr_carousel_notice','I due caroselli sono già presenti. Nessuna modifica eseguita.',false);
        } else {
            $keys = array(); foreach(array('dispositivo','ambiente') as $key) for($n=1;$n<=5;$n++) $keys[]=$key.'-'.$n;
            $urls = plr_media($keys); $replacement = array();
            foreach(array('dispositivo','ambiente') as $key) {
                $file = file_get_contents(PLR_DIR.'pages/carousel-'.$key.'.html');
                if ($file === false) throw new Exception('Modello del carosello mancante.');
                $parsed = parse_blocks(strtr($file,$urls)); $replacement[$key] = $parsed[0];
            }
            foreach($plan as $key=>$path) {
                $target = &plr_carousel_at($blocks,$path);
                $target = $replacement[$key];
                unset($target);
            }
            if (get_post_field('post_content',$id) !== $before) throw new Exception('La Home è stata modificata nel frattempo. Riprova.');
            add_post_meta($id,'_plr_carousel_backup',wp_slash($before),true);
            $result = wp_update_post(wp_slash(array('ID'=>$id,'post_content'=>serialize_blocks($blocks))),true);
            if (is_wp_error($result)) throw new Exception($result->get_error_message());
            update_option('plr_carousel_notice','Home aggiornata: due caroselli da cinque immagini. Testi e intestazione conservati. Apri Anteprima per verificarli.',false);
        }
    } catch(Exception $e) { update_option('plr_carousel_notice',$e->getMessage(),false); }
    delete_option('plr_import_lock');
    wp_safe_redirect(admin_url('tools.php?page=plr-pagine')); exit;
}
add_action('admin_post_plr_carousels','plr_carousels');
