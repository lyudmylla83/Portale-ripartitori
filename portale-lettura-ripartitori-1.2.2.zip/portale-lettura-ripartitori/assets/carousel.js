(function(){'use strict';
function init(root,index){
 if(root.dataset.plrReady)return;
 const track=root.querySelector(':scope > .wp-block-group__inner-container')||root;
 const slides=Array.from(track.children).filter(n=>n.matches('figure.wp-block-image'));
 if(slides.length<2)return;
 root.dataset.plrReady='1';root.classList.add('plr-carousel-ready');
 root.setAttribute('role','region');root.setAttribute('aria-roledescription','carosello');root.setAttribute('aria-label',root.classList.contains('plr-carousel-dispositivo')?'Foto dei ripartitori':'Foto degli ambienti');
 let current=0;
 const controls=document.createElement('div');controls.className='plr-carousel-controls';
 const status=document.createElement('span');status.className='plr-carousel-status';status.setAttribute('aria-live','polite');status.setAttribute('aria-atomic','true');
 function button(text,label){const n=document.createElement('button');n.type='button';n.textContent=text;n.setAttribute('aria-label',label);return n;}
 const prev=button('‹','Immagine precedente'),next=button('›','Immagine successiva');
 const dots=document.createElement('div');dots.className='plr-carousel-dots';
 const tabs=slides.map((slide,i)=>{slide.id='plr-slide-'+index+'-'+i;slide.setAttribute('role','group');slide.setAttribute('aria-roledescription','diapositiva');slide.setAttribute('aria-label',(i+1)+' di '+slides.length);const dot=button('','Mostra immagine '+(i+1));dot.setAttribute('aria-controls',slide.id);dot.addEventListener('click',()=>show(i));dots.append(dot);return dot;});
 function show(i){current=(i+slides.length)%slides.length;slides.forEach((s,j)=>{s.hidden=j!==current;s.setAttribute('aria-hidden',String(j!==current));tabs[j].setAttribute('aria-pressed',String(j===current));});status.textContent=(current+1)+' / '+slides.length;}
 prev.addEventListener('click',()=>show(current-1));next.addEventListener('click',()=>show(current+1));
 controls.append(prev,dots,next,status);root.append(controls);show(0);
 root.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();show(current+(e.key==='ArrowRight'?1:-1));}});
 let start=null;root.addEventListener('touchstart',e=>{const t=e.changedTouches[0];start={x:t.clientX,y:t.clientY};},{passive:true});root.addEventListener('touchend',e=>{if(!start)return;const t=e.changedTouches[0],dx=t.clientX-start.x,dy=t.clientY-start.y;if(Math.abs(dx)>50&&Math.abs(dx)>Math.abs(dy)*1.5)show(current+(dx<0?1:-1));start=null;},{passive:true});
}
function boot(){document.querySelectorAll('.plr-page .plr-carousel').forEach(init);}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
