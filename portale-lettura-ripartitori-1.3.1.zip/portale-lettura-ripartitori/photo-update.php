<?php
if (!defined('ABSPATH')) exit;
function plr_photo_controls() {
    echo '<h2>Foto aggiornate e logo LR</h2><p>Aggiorna le immagini delle quattro pagine del progetto e i due caroselli (4 dispositivi, 5 ambienti). Imposta il logo LR e l’icona del sito. Conserva testi e stato delle pagine; salva una copia del contenuto precedente.</p>';
    $notice=get_option('plr_photo_notice'); if($notice) echo '<p>'.esc_html($notice).'</p>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('plr_photos');
    echo '<input type="hidden" name="action" value="plr_photos">';submit_button('Aggiorna foto, logo e favicon','secondary');echo '</form>';
}
function plr_photo_import() {
    require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
    $ids=(array)get_option('plr_photo_ids_130',array());
    $keys=array('pc','mobile','tablet','montaggio','studio','ripartitore','dispositivo-1','dispositivo-2','dispositivo-3','dispositivo-4','ambiente-1','ambiente-2','ambiente-3','ambiente-4','ambiente-5','logo-lr');
    foreach($keys as $key){
        if(!empty($ids[$key]) && wp_get_attachment_url($ids[$key])) continue;
        $ext=$key==='logo-lr'?'.png':'.jpg';$tmp=wp_tempnam($key.$ext);
        if(!$tmp || !copy(PLR_DIR.'assets/'.$key.$ext,$tmp)) throw new Exception('Immagine non disponibile: '.$key);
        $id=media_handle_sideload(array('name'=>'portale-130-'.$key.$ext,'tmp_name'=>$tmp),0,'Portale — '.$key);
        if(is_wp_error($id)){if(file_exists($tmp)) unlink($tmp);throw new Exception($id->get_error_message());}
        $ids[$key]=$id;update_option('plr_photo_ids_130',$ids,false);
    }
    return $ids;
}
function plr_photo_transform($blocks,$urls,$old_urls) {
    foreach($blocks as &$block){
        $classes=preg_split('/\s+/',trim($block['attrs']['className']??''));$replaced=false;
        foreach(array('dispositivo','ambiente') as $kind){
            if(in_array('plr-carousel-'.$kind,$classes,true)){
                $parsed=parse_blocks(strtr(file_get_contents(PLR_DIR.'pages/carousel-'.$kind.'.html'),$urls));
                $block=$parsed[0];$replaced=true;break;
            }
        }
        if($replaced) continue;
        if(($block['blockName']??'')==='core/image'){
            $html=$block['innerHTML'];
            if(preg_match('/\bsrc="([^"]+)"/',$html,$m)){
                $src=html_entity_decode($m[1],ENT_QUOTES,'UTF-8');
                foreach($old_urls as $key=>$candidates){
                    if(!in_array($src,$candidates,true)||!isset($urls['{{asset:'.$key.'}}']))continue;
                    $html=preg_replace('/\bsrc="[^"]+"/','src="'.$urls['{{asset:'.$key.'}}'].'"',$html,1);
                    $html=preg_replace('/\s(?:srcset|sizes)="[^"]*"/','',$html);
                    $html=preg_replace('/\s*wp-image-\d+/','',$html);
                    unset($block['attrs']['id'],$block['attrs']['width'],$block['attrs']['height'],$block['attrs']['aspectRatio'],$block['attrs']['scale']);
                    $html=preg_replace('/\s(?:width|height)="[^"]*"/','',$html);
                    $block['innerHTML']=$html;$block['innerContent']=array($html);break;
                }
            }
        }
        if(!empty($block['innerBlocks']))$block['innerBlocks']=plr_photo_transform($block['innerBlocks'],$urls,$old_urls);
    }
    return $blocks;
}
function plr_photos(){
    if(!current_user_can('manage_options')||!current_user_can('edit_pages')||!current_user_can('upload_files'))wp_die('Permessi insufficienti.');
    check_admin_referer('plr_photos');
    if(!add_option('plr_import_lock',time(),'','no'))wp_die('Operazione in corso. Riprova tra poco.');
    try{
        $pages=(array)get_option('plr_page_ids',array());if(!$pages)throw new Exception('Importa prima le quattro pagine.');
        $new=plr_photo_import();$urls=array();foreach($new as $key=>$id)$urls['{{asset:'.$key.'}}']=esc_url(wp_get_attachment_url($id));
        $old=(array)get_option('plr_media_ids',array());$old_urls=array();
        foreach($old as $key=>$id){$old_urls[$key]=array(wp_get_attachment_url($id));foreach(array('thumbnail','medium','medium_large','large','full') as $size){$image=wp_get_attachment_image_src($id,$size);if($image)$old_urls[$key][]=$image[0];}}
        $plans=array();
        foreach($pages as $id){
            $post=get_post($id);if(!$post||!get_post_meta($id,'_plr_owned',true)||!current_user_can('edit_post',$id))throw new Exception('Pagina del progetto non modificabile.');
            // Repeated clicks do not overwrite subsequent manual choices.
            if(get_post_meta($id,'_plr_photos_130',true))continue;
            $before=$post->post_content;$after=serialize_blocks(plr_photo_transform(parse_blocks(str_replace(array('Portale Lettura Ripartitori','PORTALE LETTURA RIPARTITORI'),array('Lettura Ripartitori','LETTURA RIPARTITORI'),$before)),$urls,$old_urls));
            $plans[]=array($id,$before,$after);
        }
        foreach($plans as $plan){list($id,$before,$after)=$plan;if(get_post_field('post_content',$id)!==$before)throw new Exception('Una pagina è stata modificata nel frattempo. Riprova.');}
        foreach($plans as $plan){list($id,$before,$after)=$plan;add_post_meta($id,'_plr_photos_backup_130',wp_slash($before),true);if($before!==$after){$r=wp_update_post(wp_slash(array('ID'=>$id,'post_content'=>$after)),true);if(is_wp_error($r))throw new Exception($r->get_error_message());}update_post_meta($id,'_plr_photos_130',1);}
        $header=(int)get_option('plr_header_id');
        if($header && !get_post_meta($header,'_plr_name_130',true)){
            if(!current_user_can('edit_post',$header))throw new Exception('Intestazione non modificabile.');
            $before=get_post_field('post_content',$header);
            $after=str_replace('Portale Lettura Ripartitori','Lettura Ripartitori',$before);
            add_post_meta($header,'_plr_name_backup_130',wp_slash($before),true);
            if($before!==$after){$result=wp_update_post(wp_slash(array('ID'=>$header,'post_content'=>$after)),true);if(is_wp_error($result))throw new Exception($result->get_error_message());}
            update_post_meta($header,'_plr_name_130',1);
        }
        if(!get_option('plr_logo_130')){
            add_option('plr_brand_backup_130',array('site_icon'=>get_option('site_icon'),'custom_logo'=>get_theme_mod('custom_logo'),'blogname'=>get_option('blogname')),'','no');
            update_option('blogname','Lettura Ripartitori');update_option('site_icon',$new['logo-lr']);set_theme_mod('custom_logo',$new['logo-lr']);update_option('plr_logo_130',$new['logo-lr'],false);
        }
        if(!get_option('plr_logo_amber_131')) plr_amber_logo_apply();
        update_option('plr_photo_notice','Foto, logo LR e favicon aggiornati. Controlla le anteprime delle pagine.',false);
    }catch(Exception $e){update_option('plr_photo_notice',$e->getMessage(),false);}
    delete_option('plr_import_lock');wp_safe_redirect(admin_url('tools.php?page=plr-pagine'));exit;
}
add_action('admin_post_plr_photos','plr_photos');
add_filter('render_block',function($html,$block){
    if(is_admin()||!plr_active_page()||!get_option('plr_logo_130'))return $html;
    $classes=preg_split('/\s+/',trim($block['attrs']['className']??''));
    if(($block['blockName']??'')==='core/paragraph' && in_array('plr-brand',$classes,true) && strpos($html,'<img')===false){
        $image=wp_get_attachment_image((int)get_option('plr_logo_130'),'full',false,array('class'=>'plr-logo','alt'=>'Lettura Ripartitori','width'=>56,'height'=>56));
        $html=preg_replace('/(<p\b[^>]*>)/','$1'.$image,$html,1);
    }
    return $html;
},20,2);
