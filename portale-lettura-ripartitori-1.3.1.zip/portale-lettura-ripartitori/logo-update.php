<?php
if(!defined('ABSPATH'))exit;
function plr_amber_logo_apply(){
    require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
    $id=(int)get_option('plr_logo_amber_131');
    if(!$id || !wp_get_attachment_url($id)){
        $tmp=wp_tempnam('logo-lr-ambra.png');
        if(!$tmp || !copy(PLR_DIR.'assets/logo-lr.png',$tmp))throw new Exception('Impossibile preparare il logo ambra.');
        $id=media_handle_sideload(array('name'=>'lettura-ripartitori-logo-ambra-131.png','tmp_name'=>$tmp),0,'Lettura Ripartitori — Logo LR ambra');
        if(is_wp_error($id)){if(file_exists($tmp))unlink($tmp);throw new Exception($id->get_error_message());}
        update_option('plr_logo_amber_131',$id,false);
    }
    add_option('plr_logo_backup_131',array('site_icon'=>get_option('site_icon'),'custom_logo'=>get_theme_mod('custom_logo'),'plr_logo_130'=>get_option('plr_logo_130')),'','no');
    update_option('plr_logo_130',$id,false);update_option('site_icon',$id);set_theme_mod('custom_logo',$id);
    return $id;
}
function plr_amber_logo_action(){
    if(!current_user_can('manage_options')||!current_user_can('upload_files'))wp_die('Permessi insufficienti.');
    check_admin_referer('plr_amber_logo');
    if(!add_option('plr_import_lock',time(),'','no'))wp_die('Operazione in corso. Riprova tra poco.');
    try{plr_amber_logo_apply();update_option('plr_logo_notice','Logo ambra e favicon aggiornati su tutte le pagine del portale.',false);}
    catch(Exception $e){update_option('plr_logo_notice',$e->getMessage(),false);}
    delete_option('plr_import_lock');wp_safe_redirect(admin_url('tools.php?page=plr-pagine'));exit;
}
add_action('admin_post_plr_amber_logo','plr_amber_logo_action');
function plr_amber_logo_controls(){
    echo '<h2>Logo LR ambra</h2><p>Sostituisce il logo nell’intestazione condivisa e la favicon. Foto, testi e caroselli restano invariati.</p>';
    $notice=get_option('plr_logo_notice');if($notice)echo '<p>'.esc_html($notice).'</p>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('plr_amber_logo');echo '<input type="hidden" name="action" value="plr_amber_logo">';submit_button('Aggiorna logo ambra e favicon','secondary');echo '</form>';
}
