<?php
/**
 * Plugin Name: Portale Lettura Ripartitori — Pagine Gutenberg
 * Description: Quattro pagine modificabili, immagini e stili del progetto. Importazione in bozza senza sovrascrivere pagine esistenti.
 * Version: 1.3.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: plr-pagine
 */
if (!defined('ABSPATH')) { exit; }
define('PLR_DIR', plugin_dir_path(__FILE__));
define('PLR_URL', plugin_dir_url(__FILE__));
function plr_titles() { return array('home'=>'Home','come-funziona'=>'Come funziona','cosa-risolve'=>'Cosa risolve','normative'=>'Normative'); }
function plr_active_page() { return is_singular('page') && get_post_meta(get_queried_object_id(), '_plr_owned', true); }
function plr_assets() {
    if (is_admin() || plr_active_page()) {
        wp_enqueue_style('plr-pagine', PLR_URL.'assets/site.css', array(), '1.3.0');
    }
}
add_action('enqueue_block_assets', 'plr_assets');
add_action('wp_enqueue_scripts', 'plr_assets');
add_action('wp_enqueue_scripts', function(){ if(plr_active_page()) wp_enqueue_script('plr-carousel', PLR_URL.'assets/carousel.js', array(), '1.3.0', true); });
add_filter('template_include', function($template) { return plr_active_page() ? PLR_DIR.'template.php' : $template; }, 99);
add_filter('body_class', function($classes) { if(plr_active_page()) $classes[]='plr-site'; return $classes; });
// Links between drafts work for an editor in preview, while published pages use normal permalinks.
add_filter('render_block', function($content, $block) {
    if (is_admin() || !plr_active_page() || !current_user_can('edit_pages')) return $content;
    foreach ((array)get_option('plr_page_ids', array()) as $id) {
        if (get_post_status($id)==='draft' && current_user_can('edit_post', $id)) {
            $url=get_permalink($id); $preview=get_preview_post_link($id);
            if ($url && $preview) $content=str_replace('href="'.esc_url($url).'"', 'href="'.esc_url($preview).'"', $content);
        }
    }
    return $content;
}, 10, 2);
function plr_admin_menu() { add_management_page('Portale Ripartitori','Portale Ripartitori','manage_options','plr-pagine','plr_admin_screen'); }
add_action('admin_menu','plr_admin_menu');
function plr_admin_screen() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>Portale Lettura Ripartitori</h1><p>Importa quattro pagine in bozza e le immagini del progetto. Le pagine esistenti, la homepage e il menu del tema non vengono modificati.</p>';
    $error=get_option('plr_import_error'); if($error) echo '<div class="notice notice-error"><p>'.esc_html($error).'</p></div>';
    $ids=(array)get_option('plr_page_ids',array());
    foreach(plr_titles() as $key=>$title) {
        if(!empty($ids[$key]) && get_post($ids[$key])) echo '<p><strong>'.esc_html($title).'</strong> — <a href="'.esc_url(get_edit_post_link($ids[$key])).'">Modifica in Gutenberg</a> · <a href="'.esc_url(get_preview_post_link($ids[$key])).'">Anteprima</a></p>';
    }
    plr_carousel_form($ids);
    plr_footer_controls();
    plr_photo_controls();
    $header=(int)get_option('plr_header_id');
    if($header && get_post($header)) echo '<p><a href="'.esc_url(get_edit_post_link($header)).'">Modifica intestazione condivisa</a></p>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
    wp_nonce_field('plr_import');
    echo '<input type="hidden" name="action" value="plr_import">';
    submit_button($ids?'Completa importazione senza sovrascrivere':'Crea le quattro pagine in bozza');
    echo '</form><h2>Come modificare</h2><p>Apri una pagina, seleziona un testo o un’immagine e modificalo. Gli stili sono limitati alle pagine importate. L’intestazione è condivisa: le sue modifiche si applicano alle quattro pagine.</p><p>Le immagini del portale sono dimostrative. Verifica la pagina Normative prima di pubblicarla. Per impostare la Home pubblica, pubblicala e selezionala successivamente in Impostazioni → Lettura.</p><p>Disattivando il plugin i contenuti e le immagini restano, ma si perde il layout dedicato. Non sono presenti moduli, tracciamenti o collegamenti al database del software.</p></div>';
}
add_action('admin_notices', function() {
    if(current_user_can('manage_options') && !get_option('plr_import_complete')) echo '<div class="notice notice-info"><p>Portale Ripartitori pronto. <a href="'.esc_url(admin_url('tools.php?page=plr-pagine')).'">Crea le quattro pagine in bozza</a>.</p></div>';
});
function plr_media($only = null) {
    require_once ABSPATH.'wp-admin/includes/file.php';
    require_once ABSPATH.'wp-admin/includes/media.php';
    require_once ABSPATH.'wp-admin/includes/image.php';
    $ids=(array)get_option('plr_media_ids',array()); $urls=array();
    foreach($only === null ? array('pc','mobile','tablet','montaggio','studio','ripartitore','dispositivo-1','dispositivo-2','dispositivo-3','dispositivo-4','dispositivo-5','ambiente-1','ambiente-2','ambiente-3','ambiente-4','ambiente-5') : $only as $key) {
        if(empty($ids[$key]) || !wp_get_attachment_url($ids[$key])) {
            $tmp=wp_tempnam($key.'.jpg');
            if(!$tmp || !copy(PLR_DIR.'assets/'.$key.'.jpg',$tmp)) throw new Exception('Impossibile preparare l’immagine '.$key.'.');
            $id=media_handle_sideload(array('name'=>'portale-'.$key.'.jpg','tmp_name'=>$tmp),0,'Portale — '.$key);
            if(is_wp_error($id)) { if(file_exists($tmp)) unlink($tmp); throw new Exception($id->get_error_message()); }
            $ids[$key]=$id;update_option('plr_media_ids',$ids,false);
        }
        $urls['{{asset:'.$key.'}}']=esc_url(wp_get_attachment_url($ids[$key]));
    }
    return $urls;
}
function plr_import() {
    if(!current_user_can('manage_options') || !current_user_can('edit_pages') || !current_user_can('upload_files')) wp_die('Permessi insufficienti.');
    check_admin_referer('plr_import');
    if(!add_option('plr_import_lock',time(),'','no')) { if(time()-(int)get_option('plr_import_lock')<300) wp_die('Importazione già in corso. Attendi e ricarica.'); delete_option('plr_import_lock'); if(!add_option('plr_import_lock',time(),'','no')) wp_die('Riprova tra poco.'); }
    try {
        $replacements=plr_media();$ids=(array)get_option('plr_page_ids',array());
        foreach(plr_titles() as $key=>$title) {
            if(!empty($ids[$key]) && get_post($ids[$key])) continue;
            $existing=get_page_by_path($key,OBJECT,'page');
            $id=wp_insert_post(array('post_type'=>'page','post_status'=>'draft','post_title'=>$title,'post_name'=>$existing?'plr-'.$key:$key,'post_content'=>'','meta_input'=>array('_plr_owned'=>1)),true);
            if(is_wp_error($id)) throw new Exception($id->get_error_message());
            $ids[$key]=$id;update_option('plr_page_ids',$ids,false);
        }
        foreach($ids as $key=>$id) $replacements['{{page:'.$key.'}}']=esc_url(get_permalink($id));
        foreach($ids as $key=>$id) {
            if(get_post_meta($id,'_plr_seeded',true)) continue;
            // Preserve even a partially imported page if a person already edited it.
            if(trim((string)get_post_field('post_content',$id))!=='') { update_post_meta($id,'_plr_seeded',1);continue; }
            $content=file_get_contents(PLR_DIR.'pages/'.$key.'.html');
            if($content===false) throw new Exception('Modello mancante: '.$key);
            $result=wp_update_post(wp_slash(array('ID'=>$id,'post_content'=>strtr($content,$replacements))),true);
            if(is_wp_error($result)) throw new Exception($result->get_error_message());
            update_post_meta($id,'_plr_seeded',1);
        }
        $header=(int)get_option('plr_header_id');
        if(!$header || !get_post($header)) {
            $content=strtr(file_get_contents(PLR_DIR.'pages/header.html'),$replacements);
            $header=wp_insert_post(wp_slash(array('post_type'=>'wp_block','post_status'=>'publish','post_title'=>'Portale — Intestazione condivisa','post_content'=>$content)),true);
            if(is_wp_error($header)) throw new Exception($header->get_error_message());
            update_option('plr_header_id',$header,false);
        }
        delete_option('plr_import_error');update_option('plr_import_complete',1,false);
    } catch(Exception $e) { update_option('plr_import_error',$e->getMessage(),false); }
    delete_option('plr_import_lock');wp_safe_redirect(admin_url('tools.php?page=plr-pagine'));exit;
}
add_action('admin_post_plr_import','plr_import');

require_once PLR_DIR . 'carousel-update.php';

require_once PLR_DIR . 'footer.php';

require_once PLR_DIR . 'photo-update.php';
