<?php
if (!defined('ABSPATH')) exit;
function plr_footer_post() {
    $id=(int)get_option('plr_footer_id');
    $post=$id?get_post($id):null;
    return $post && $post->post_type==='wp_block' && $post->post_status==='publish' ? $post : null;
}
function plr_footer_controls() {
    $post=plr_footer_post();
    echo '<h2>Footer condiviso</h2>';
    if ($post) {
        echo '<p>Il footer è attivo su tutte le pagine del progetto. <a href="'.esc_url(get_edit_post_link($post->ID)).'">Modifica footer condiviso</a>. Le modifiche si applicano a tutte le pagine.</p>';
    } else {
        echo '<p>Crea un pattern sincronizzato con Contatti, email e attribuzione. Il footer compare automaticamente sulle pagine del progetto, senza modificare il loro contenuto.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('plr_footer_create');
        echo '<input type="hidden" name="action" value="plr_footer_create">';
        submit_button('Attiva footer condiviso','secondary');
        echo '</form>';
    }
}
function plr_footer_create() {
    if (!current_user_can('manage_options') || !current_user_can('edit_pages')) wp_die('Permessi insufficienti.');
    check_admin_referer('plr_footer_create');
    if (plr_footer_post()) { wp_safe_redirect(admin_url('tools.php?page=plr-pagine'));exit; }
    if (!add_option('plr_footer_lock',time(),'','no')) {
        if(time()-(int)get_option('plr_footer_lock')<300) wp_die('Creazione footer già in corso. Riprova tra poco.');
        delete_option('plr_footer_lock');
        if(!add_option('plr_footer_lock',time(),'','no')) wp_die('Riprova tra poco.');
    }
    $content=file_get_contents(PLR_DIR.'pages/footer.html');
    if ($content===false) {delete_option('plr_footer_lock');wp_die('Modello footer mancante.');}
    $id=wp_insert_post(wp_slash(array('post_type'=>'wp_block','post_status'=>'publish','post_title'=>'Portale — Footer condiviso','post_content'=>$content)),true);
    if(is_wp_error($id)) {delete_option('plr_footer_lock');wp_die(esc_html($id->get_error_message()));}
    update_option('plr_footer_id',$id,false);
    delete_option('plr_footer_lock');
    wp_safe_redirect(admin_url('tools.php?page=plr-pagine'));exit;
}
add_action('admin_post_plr_footer_create','plr_footer_create');
function plr_render_footer() {
    $post=plr_footer_post();
    if($post) echo '<footer class="plr-footer" aria-label="Contatti">'.do_blocks($post->post_content).'</footer>';
}
